# Alura cursos online - Fundamentos Django 2 (Parte 2): Uma aplicação web

Projeto da Alura cursos online, desenvolvido em Python3 com framework Django

## Projeto final aula 1

Nessa aula:

- Alteramos o Admin do Django para exibir o nome de cada receita através da função [__str__](https://docs.djangoproject.com/pt-br/2.2/howto/custom-model-fields/);

- Adicionamos filtros, buscas e paginação alterando o código do [admin.py](https://docs.djangoproject.com/en/2.2/ref/contrib/admin/).
