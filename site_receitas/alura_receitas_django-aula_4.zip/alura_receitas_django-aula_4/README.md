# Alura cursos online - Fundamentos Django 2: Uma aplicação web

Projeto da Alura cursos online, desenvolvido em Python3 com framework Django

## Projeto final aula 4

Nessa aula:

- Aprendemos como enviar dados para o template renderizar;

- Instalamos e configuramos o banco de dados Postgres com a nossa aplicação;

- Criamos o modelo de receitas e mapeamos para uma tabela no banco de dados.



