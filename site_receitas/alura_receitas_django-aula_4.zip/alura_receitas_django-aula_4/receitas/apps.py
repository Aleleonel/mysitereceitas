from django.apps import AppConfig


class ReceitasConfig(AppConfig):
    name = 'receitas'
