# Alura cursos online - Fundamentos Django 2: Uma aplicação web

Projeto da Alura cursos online, desenvolvido em Python3 com framework Django

## Projeto final aula 5

Nessa aula:

- Aprendemos como enviar e exibir dados para uma página;

- Exibimos as receitas que estão no banco de dados;

- Alteramos a `url` da index, exibindo como cada receita é feita, seus ingredientes e outras informações.


